package br.com.aidavec.aidavec.models;

import java.util.Arrays;
import java.util.List;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class Vehicle {
    public int vei_id;
    public int usr_id;
    public String vei_marca;
    public String vei_modelo;
    public String vei_ano;
    public String vei_cor;
    public String vei_cobertura;
    public String photoA;
    public String photoB;
    public String photoC;

    private static String[] Marcas = {"Marca", "Volkswagen", "Chevrolet","Ford","Fiat"};

    private static String[][] Modelos = {
            {"Modelo", "Gol", "Passat", "Jetta", "Fox"},
            {"Modelo", "Onix", "Cruze", "Omega", "Cobalt"},
            {"Modelo", "Fiesta", "Ka", "Focus", "Fusion"},
            {"Modelo", "Uno", "Palio", "Toro", "500"}
    };

    private static String[] Anos = {"Ano", "2000", "2001","2002","2003","2004","2005",
            "2006","2007","2008","2009"};

    private static String[] Cores = {"Cor", "Branco", "Preto","Prata"};

    private static String[] Coberturas = {"Cobertura", "Paga", "Free","Parcial"};


    public int getVei_id() {
        return vei_id;
    }

    public void setVei_id(int vei_id) {
        this.vei_id = vei_id;
    }

    public int getUsr_id() {
        return usr_id;
    }

    public void setUsr_id(int usr_id) {
        this.usr_id = usr_id;
    }

    public String getVei_marca() {
        return vei_marca;
    }

    public void setVei_marca(String vei_marca) {
        this.vei_marca = vei_marca;
    }

    public String getVei_modelo() {
        return vei_modelo;
    }

    public void setVei_modelo(String vei_modelo) {
        this.vei_modelo = vei_modelo;
    }

    public String getVei_ano() {
        return vei_ano;
    }

    public void setVei_ano(String vei_ano) {
        this.vei_ano = vei_ano;
    }

    public String getVei_cor() {
        return vei_cor;
    }

    public void setVei_cor(String vei_cor) {
        this.vei_cor = vei_cor;
    }

    public String getVei_cobertura() {
        return vei_cobertura;
    }

    public void setVei_cobertura(String vei_cobertura) {
        this.vei_cobertura = vei_cobertura;
    }

    public String getPhotoA() {
        return photoA;
    }

    public void setPhotoA(String photoA) {
        this.photoA = photoA;
    }

    public String getPhotoB() {
        return photoB;
    }

    public void setPhotoB(String photoB) {
        this.photoB = photoB;
    }

    public String getPhotoC() {
        return photoC;
    }

    public void setPhotoC(String photoC) {
        this.photoC = photoC;
    }

    public static List<String> getMarcasList(){
        return Arrays.asList(Marcas);
    }

    public static List<String> getAnosList(){
        return Arrays.asList(Anos);
    }

    public static List<String> getCoresList(){
        return Arrays.asList(Cores);
    }

    public static List<String> getCoberturasList(){
        return Arrays.asList(Coberturas);
    }

    public static List<String> getModelosbyMarca(int id){
        return Arrays.asList(Modelos[id]);
    }

}
