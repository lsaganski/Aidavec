package br.com.aidavec.aidavec.models;

/**
 * Created by leonardo.saganski on 30/12/16.
 */

public class Note {
    public int not_id;
    public int usr_id;
    public String not_titulo;
    public String not_mensagem;
    public String not_tipo;
    public String not_opcaoa;
    public String not_opcaob;
    public String not_opcaoc;
    public String not_opcaod;
    public String not_opcaoe;
    public String not_resposta;
    public int not_push;

    public int getNot_id() {
        return not_id;
    }

    public void setNot_id(int not_id) {
        this.not_id = not_id;
    }

    public int getUsr_id() {
        return usr_id;
    }

    public void setUsr_id(int usr_id) {
        this.usr_id = usr_id;
    }

    public String getNot_titulo() {
        return not_titulo;
    }

    public void setNot_titulo(String not_titulo) {
        this.not_titulo = not_titulo;
    }

    public String getNot_mensagem() {
        return not_mensagem;
    }

    public void setNot_mensagem(String not_mensagem) {
        this.not_mensagem = not_mensagem;
    }

    public String getNot_tipo() {
        return not_tipo;
    }

    public void setNot_tipo(String not_tipo) {
        this.not_tipo = not_tipo;
    }

    public String getNot_opcaoa() {
        return not_opcaoa;
    }

    public void setNot_opcaoa(String not_opcaoa) {
        this.not_opcaoa = not_opcaoa;
    }

    public String getNot_opcaob() {
        return not_opcaob;
    }

    public void setNot_opcaob(String not_opcaob) {
        this.not_opcaob = not_opcaob;
    }

    public String getNot_opcaoc() {
        return not_opcaoc;
    }

    public void setNot_opcaoc(String not_opcaoc) {
        this.not_opcaoc = not_opcaoc;
    }

    public String getNot_opcaod() {
        return not_opcaod;
    }

    public void setNot_opcaod(String not_opcaod) {
        this.not_opcaod = not_opcaod;
    }

    public String getNot_opcaoe() {
        return not_opcaoe;
    }

    public void setNot_opcaoe(String not_opcaoe) {
        this.not_opcaoe = not_opcaoe;
    }

    public String getNot_resposta() {
        return not_resposta;
    }

    public void setNot_resposta(String not_resposta) {
        this.not_resposta = not_resposta;
    }

    public int getNot_push() {
        return not_push;
    }

    public void setNot_push(int not_push) {
        this.not_push = not_push;
    }
}
