package br.com.aidavec.aidavec.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import br.com.aidavec.aidavec.R;
import br.com.aidavec.aidavec.core.Api;
import br.com.aidavec.aidavec.core.Globals;
import br.com.aidavec.aidavec.helpers.Utils;
import br.com.aidavec.aidavec.models.Note;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class NoteDetailsFrag extends Fragment implements View.OnClickListener {

    public static Note obj;
    LinearLayout llMensagem;
    LinearLayout llDireto;
    LinearLayout llMultiplo;

    TextView lblTitulo;
    TextView lblMensagem;

    Button btnSim;
    Button btnNao;
    Button btnA;
    Button btnB;
    Button btnC;
    Button btnD;
    Button btnE;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            Utils.Show("Resposta salva..", true);
            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.nav_contentframe, new NoteFrag(), "TAG").commit();
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_note_details, container, false);

        Globals.getInstance().clearCountUnreadNotes();

        loadComponents(v);

        setUI();

        loadEvents();

        return v;
    }

    private void loadComponents(View v) {
        llMensagem = (LinearLayout) v.findViewById(R.id.llMessage);
        llDireto = (LinearLayout) v.findViewById(R.id.llDireto);
        llMultiplo = (LinearLayout) v.findViewById(R.id.llMultiplo);

        lblTitulo = (TextView) v.findViewById(R.id.lblTitulo);
        lblMensagem = (TextView) v.findViewById(R.id.lblMensagem);

        btnSim = (Button) v.findViewById(R.id.btnSim);
        btnNao = (Button) v.findViewById(R.id.btnNao);

        btnA = (Button) v.findViewById(R.id.btnA);
        btnB = (Button) v.findViewById(R.id.btnB);
        btnC = (Button) v.findViewById(R.id.btnC);
        btnD = (Button) v.findViewById(R.id.btnD);
        btnE = (Button) v.findViewById(R.id.btnE);
    }

    private void setUI(){
        lblTitulo.setText(obj.getNot_titulo());
        lblMensagem.setText(obj.getNot_mensagem());

        if (obj != null) {

            if (obj.getNot_tipo().equals("0")) {
                llDireto.setVisibility(View.GONE);
                llMultiplo.setVisibility(View.GONE);
            } else if (obj.getNot_tipo().equals("1")) {
                llDireto.setVisibility(View.VISIBLE);
                llMultiplo.setVisibility(View.GONE);
                btnSim.setText(obj.getNot_opcaoa());
                btnNao.setText(obj.getNot_opcaob());
            } else {
                llDireto.setVisibility(View.GONE);
                llMultiplo.setVisibility(View.VISIBLE);
                btnA.setText(obj.getNot_opcaoa());
                btnB.setText(obj.getNot_opcaob());
                btnC.setText(obj.getNot_opcaoc());
                btnD.setText(obj.getNot_opcaod());
                btnE.setText(obj.getNot_opcaoe());
            }
        }
    }

    private void loadEvents(){
        btnSim.setOnClickListener(this);

        btnNao.setOnClickListener(this);

        btnA.setOnClickListener(this);

        btnB.setOnClickListener(this);

        btnC.setOnClickListener(this);

        btnD.setOnClickListener(this);

        btnE.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Button btn = (Button) v;
        obj.setNot_resposta(btn.getText().toString());
        Api.getInstance().SaveNote(handler, obj);
    }
}
