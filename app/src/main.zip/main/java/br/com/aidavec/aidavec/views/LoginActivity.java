package br.com.aidavec.aidavec.views;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import br.com.aidavec.aidavec.R;
import br.com.aidavec.aidavec.base.BaseActivity;
import br.com.aidavec.aidavec.core.Globals;
import br.com.aidavec.aidavec.core.Api;
import br.com.aidavec.aidavec.helpers.Utils;
import br.com.aidavec.aidavec.models.User;
import br.com.aidavec.aidavec.models.Vehicle;

public class LoginActivity extends BaseActivity {

    Context context;

    EditText txtUserName;
    EditText txtPassword;

    TextView lblTitle;
    ProgressBar progress;

/*    Handler handlerVehicle = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1) {

                Globals.getInstance().saveVehicleInPrefs();
                lblTitle.setVisibility(View.VISIBLE);
                progress.setVisibility(View.GONE);

            } else {
                Utils.Show("Erro ao logar. Tente novamente.", true);
            }

        }
    };*/

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                Globals.getInstance().saveUserInPrefs();

                Api.getInstance().GetVehicle(null);

                Intent intent = new Intent(context, MainActivity.class);
                startActivity(intent);

            } else if (msg.what == 2) {
                Utils.Show("Seu cadastro ainda não foi validado. Verifique seu e-mail.", true);
            } else if (msg.what == 9) {
                Utils.Show("Erro no servidor.", true);
            } else {
                Utils.Show("Usuário ou senha inválidos. Tente novamente.", true);
            }

            lblTitle.setVisibility(View.VISIBLE);
            progress.setVisibility(View.GONE);

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        context = this;

        String userJson = Globals.getInstance().mPrefs.getString("loggedUser", "");
        User loggedUser = Globals.getInstance().gson.fromJson(userJson, User.class);

        if (loggedUser != null){
            Globals.getInstance().loggedUser = loggedUser;

            String veiJson = Globals.getInstance().mPrefs.getString("loggedVehicle", "");
            Vehicle loggedVei = Globals.getInstance().gson.fromJson(veiJson, Vehicle.class);

            if (loggedVei != null)
                Globals.getInstance().loggedVehicle = loggedVei;

            Intent intent = new Intent(context, MainActivity.class);
            startActivity(intent);
        } else {

            txtUserName = (EditText) findViewById(R.id.txtUser);
            txtPassword = (EditText) findViewById(R.id.txtPassword);
            lblTitle = (TextView) findViewById(R.id.lblTitle);
            progress = (ProgressBar) findViewById(R.id.prbProgress);
            final Button btnEnter = (Button) findViewById(R.id.btnEnter);

            txtPassword.setImeActionLabel(getResources().getString(R.string.btnEnter), EditorInfo.IME_ACTION_GO);

            txtPassword.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_GO)
                        btnEnter.performClick();
                    return true;
                }
            });

            btnEnter.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String errors = validate();

                    if (errors.length() <= 0) {
                        lblTitle.setVisibility(View.GONE);
                        progress.setVisibility(View.VISIBLE);
                        Api.getInstance().Login(handler, txtUserName.getText().toString(), txtPassword.getText().toString());
                    } else {
                        Utils.Show(errors, true);
                    }
                }
            });

            Button btnSignUp = (Button) findViewById(R.id.btnSignUp);
            btnSignUp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, SignUpActivity.class);
                    startActivity(intent);
                }
            });
        }
    }

    private String validate() {
        String errors = "";

        if (txtUserName.getText().length() <= 0 || txtPassword.getText().length() <= 0)
            errors += "Preencha todos os campos.";

        return errors;
    }
}
