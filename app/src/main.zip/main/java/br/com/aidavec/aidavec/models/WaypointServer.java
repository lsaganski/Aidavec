package br.com.aidavec.aidavec.models;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class WaypointServer {

}
