package br.com.aidavec.aidavec.services;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.NotificationCompat;
import android.util.Log;

import com.google.android.gms.location.ActivityRecognitionResult;
import com.google.android.gms.location.DetectedActivity;

import java.util.List;

import br.com.aidavec.aidavec.R;
import br.com.aidavec.aidavec.core.AidavecLocation;
import br.com.aidavec.aidavec.core.Globals;
import br.com.aidavec.aidavec.helpers.Utils;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class AidavecMotionService extends IntentService {

    private static AidavecMotionService instance;

    public static final String TAG = "AidavecMotionService";
    Context _context;

    public static AidavecMotionService getInstance() {
        if (instance == null)
            instance = new AidavecMotionService();

        return instance;
    }

    public AidavecMotionService() {
        super("AidavecMotionService");

        _context = Globals.getInstance().context;

    }

    @Override
    protected void onHandleIntent(Intent intent) {
        try {
            if (ActivityRecognitionResult.hasResult(intent)) {
                ActivityRecognitionResult result = ActivityRecognitionResult.extractResult(intent);
                handleDetectedActivities(result.getProbableActivities());
            }
        } catch (Exception e) {
            if (Utils.isMyServiceRunning(AidavecLocationService.class)) {
         //       AidavecLocationService.getInstance().stopService(new Intent(this, AidavecLocationService.class));
                AidavecLocationService.getInstance().onDestroy();
            }

            if (Utils.isMyServiceRunning(AidavecMotionService.class)) {
         //       AidavecMotionService.getInstance().stopService(new Intent(this, AidavecMotionService.class));
                AidavecMotionService.getInstance().onDestroy();
            }

        }
    }

    private void handleDetectedActivities(List<DetectedActivity> probableActivities) {
        try {
            for (DetectedActivity activity : probableActivities) {
                switch (activity.getType()) {
                    case DetectedActivity.IN_VEHICLE: {
                        Log.e("ActivityRecogition", "In Vehicle: " + activity.getConfidence());
                        if (activity.getConfidence() >= 75) {
                            NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
                            builder.setContentText("Andando de carro !!!");
                            builder.setSmallIcon(R.mipmap.ic_launcher);
                            builder.setContentTitle(getString(R.string.app_name));
                            NotificationManagerCompat.from(this).notify(0, builder.build());
                            AidavecLocation.getInstance().startLocation();
                        }

                        break;
                    }
                    case DetectedActivity.ON_BICYCLE: {
                        Log.e("ActivityRecogition", "On Bicycle: " + activity.getConfidence());
                        break;
                    }
                    case DetectedActivity.ON_FOOT: {
                        Log.e("ActivityRecogition", "On Foot: " + activity.getConfidence());
                        break;
                    }
                    case DetectedActivity.RUNNING: {
                        Log.e("ActivityRecogition", "Running: " + activity.getConfidence());
                        break;
                    }
                    case DetectedActivity.STILL: {
                        Log.e("ActivityRecogition", "Still: " + activity.getConfidence());
                        break;
                    }
                    case DetectedActivity.TILTING: {
                        Log.e("ActivityRecogition", "Tilting: " + activity.getConfidence());
                        break;
                    }
                    case DetectedActivity.WALKING: {
                        Log.e("ActivityRecogition", "Walking: " + activity.getConfidence());
                        if (activity.getConfidence() >= 75) {
                            NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
                            builder.setContentText("Indo A PÉ !!!");
                            builder.setSmallIcon(R.mipmap.ic_launcher);
                            builder.setContentTitle(getString(R.string.app_name));
                            NotificationManagerCompat.from(this).notify(0, builder.build());
                            AidavecLocation.getInstance().stopLocation();
                        }
                        break;
                    }
                    case DetectedActivity.UNKNOWN: {
                        Log.e("ActivityRecogition", "Unknown: " + activity.getConfidence());
                        break;
                    }
                }
            }
        } catch (Exception e) {
            if (Utils.isMyServiceRunning(AidavecLocationService.class)) {
         //       AidavecLocationService.getInstance().stopService(new Intent(this, AidavecLocationService.class));
                AidavecLocationService.getInstance().onDestroy();
            }

            if (Utils.isMyServiceRunning(AidavecMotionService.class)) {
        //        AidavecMotionService.getInstance().stopService(new Intent(this, AidavecMotionService.class));
                AidavecMotionService.getInstance().onDestroy();
            }
        }
    }
}
