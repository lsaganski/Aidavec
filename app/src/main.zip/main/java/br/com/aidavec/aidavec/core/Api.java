package br.com.aidavec.aidavec.core;

/**
 * Created by Leonardo Saganski on 13/12/16.
 */

import android.os.Handler;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.aidavec.aidavec.fragments.NoteFrag;
import br.com.aidavec.aidavec.helpers.PhotoMultipartRequest;
import br.com.aidavec.aidavec.helpers.Utils;
import br.com.aidavec.aidavec.helpers.VolleyHelper;
import br.com.aidavec.aidavec.models.Note;
import br.com.aidavec.aidavec.models.User;
import br.com.aidavec.aidavec.models.Vehicle;
import br.com.aidavec.aidavec.models.Waypoint;
import br.com.aidavec.aidavec.models.WaypointServer;

public class Api implements Response.ErrorListener {

    JsonObjectRequest jsonObjReq;
    JsonArrayRequest jsonArrayReq;
    int what;
    Gson gson;
    Handler handler;

    boolean ins;

    private static Api instance;

    public static Api getInstance() {
        if (instance == null)
            instance = new Api();

        return instance;
    }

    @Override
    public void onErrorResponse(VolleyError error) {

        if (error != null) {
            if (error instanceof TimeoutError || error instanceof NoConnectionError) {
                Utils.Show("Timeout Error: " + error.getMessage(), true);
            } else if (error instanceof AuthFailureError) {
                Utils.Show("Auth Error: " + error.getMessage(), true);
            } else if (error instanceof ServerError) {
                Utils.Show("Server Error: " + error.getMessage(), true);
            } else if (error instanceof NetworkError) {
                Utils.Show("Network Error: " + error.getMessage(), true);
            } else if (error instanceof ParseError) {
                Utils.Show("Parse Error: " + error.getMessage(), true);
            }

            if (error.networkResponse != null) {
                if (error.networkResponse.statusCode == 404) {
                    Utils.Show("404 Error : " + error.getMessage(), true);
                }
            }
        } else {
            Utils.Show("Error : " + error.getMessage(), true);
        }

        handler.sendEmptyMessage(0);

    }

    public void Login(Handler h, final String username, final String password) {
        try {
            handler = h;

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "login";
                int verb = Request.Method.POST;

                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONArray jArr = new JSONArray(response);
                                    if (jArr != null && jArr.length() > 0) {
                                        JSONObject jObj = (JSONObject) jArr.get(0);
                                        User user = FillUserWithJSON(jObj);
                                        if (user == null) {
                                            handler.sendEmptyMessage(0);
                                        } else if (user.getUsr_status() == 0) {
                                            handler.sendEmptyMessage(2);
                                        } else {
                                            Globals.getInstance().loggedUser = user;
                                            handler.sendEmptyMessage(1);
                                        }
                                    } else {
                                        handler.sendEmptyMessage(0);
                                    }
                                } catch (JSONException e) {
                                    handler.sendEmptyMessage(9);
                                    Utils.Show("API Error (JSon) Login : " + e.getMessage(), true);
                                }
                            }
                        }, this){

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> params = new HashMap<String, String>();
                        params.put("username", username);
                        params.put("password", Utils.HashMD5(password));
                        return params;
                    }
                };

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error Login : " + e.getMessage(), true);
        }
    }

    public void CheckEmailExists(Handler h, final String email) {
        try {
            handler = h;

            if (Globals.getInstance().loggedUser != null && Globals.getInstance().loggedUser.getUsr_id() > 0)
                handler.sendEmptyMessage(1);

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "checkemail";
                int verb = Request.Method.POST;

                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONArray jArr = new JSONArray(response);
                                    if (jArr != null && jArr.length() > 0) {
                                        JSONObject jObj = (JSONObject) jArr.get(0);
                                        User user = FillUserWithJSON(jObj);
                                        if (user == null) {
                                            handler.sendEmptyMessage(1);
                                        } else {
                                            handler.sendEmptyMessage(0);
                                        }
                                    } else {
                                        handler.sendEmptyMessage(1);
                                    }
                                } catch (JSONException e) {
                                    Utils.Show("API Error (JSon) Check Email : " + e.getMessage(), true);
                                }
                            }
                        }, this){

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> params = new HashMap<String, String>();
                        params.put("email", email);
                        return params;
                    }
                };

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error Login : " + e.getMessage(), true);
        }
    }

    public void GetNotes(Handler h) {
        try {
            handler = h;

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "notes/" + String.valueOf(Globals.getInstance().loggedUser.getUsr_id());
                int verb = Request.Method.GET;

                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONArray jArr = new JSONArray(response);
                                    List<Note> list = FillArrayNoteWithJSON(jArr);
                                    NoteFrag.listObj = list;

                                    if (handler != null)
                                        handler.sendEmptyMessage(1);
                                } catch (JSONException e) {
                                    Utils.Show("API Error (JSon) GetNotes : " + e.getMessage(), true);
                                }
                            }
                        }, this);

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error GetNotes : " + e.getMessage(), true);
        }
    }

    public void GetVehicle(Handler h) {
        try {
            handler = h;

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "vehicle/" + String.valueOf(Globals.getInstance().loggedUser.getUsr_id());
                int verb = Request.Method.GET;

                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONArray jArr = new JSONArray(response);
                                    if (jArr != null && jArr.length() > 0) {
                                        JSONObject jObj = (JSONObject) jArr.get(0);
                                        Vehicle obj = FillVehicleWithJSON(jObj);
                                        if (obj == null) {
                                            if (handler != null)
                                                handler.sendEmptyMessage(1);
                                        } else {
                                            Globals.getInstance().loggedVehicle = obj;
                                            Globals.getInstance().saveVehicleInPrefs();

                                            if (handler != null)
                                                handler.sendEmptyMessage(1);
                                        }
                                    } else {
                                        if (handler != null)
                                            handler.sendEmptyMessage(1);
                                    }
                                } catch (JSONException e) {
                                    Utils.Show("API Error (JSon) GetVehicle : " + e.getMessage(), true);
                                }
                            }
                        }, this);

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error GetVehicle : " + e.getMessage(), true);
        }
    }

    public void GetUser(Handler h) {
        try {
            handler = h;

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "user/" + String.valueOf(Globals.getInstance().loggedUser.getUsr_id());
                int verb = Request.Method.GET;

                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONArray jArr = new JSONArray(response);
                                    if (jArr != null && jArr.length() > 0) {
                                        JSONObject jObj = (JSONObject) jArr.get(0);
                                        User obj = FillUserWithJSON(jObj);
                                        if (obj == null) {
                                            handler.sendEmptyMessage(1);
                                        } else {
                                            Globals.getInstance().loggedUser = obj;
                                            Globals.getInstance().saveUserInPrefs();
                                            handler.sendEmptyMessage(1);
                                        }
                                    } else {
                                        handler.sendEmptyMessage(1);
                                    }
                                } catch (JSONException e) {
                                    Utils.Show("API Error (JSon) GetUser : " + e.getMessage(), true);
                                }
                            }
                        }, this);

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error GetUser : " + e.getMessage(), true);
        }
    }

    public void GetLastWaypoint() {
        try {
            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "waypoint";
                int verb = Request.Method.GET;

                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONArray jArr = new JSONArray(response);
                                    if (jArr != null && jArr.length() > 0) {
                                        JSONObject jObj = (JSONObject) jArr.get(0);
                                        Waypoint obj = FillWaypointWithJSON(jObj);
                                        if (obj != null) {
                                            Globals.getInstance().lastWaypointCreated = obj;
                                        }
                                    }
                                } catch (JSONException e) {
                                    Utils.Show("API Error (JSon) GetWaypoint : " + e.getMessage(), true);
                                }
                            }
                        }, this);

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error GetWaypoint : " + e.getMessage(), true);
        }
    }

    public void SaveUser(Handler h, final User obj) {
        try {
            handler = h;
            ins = true;

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "user";
                if (obj.getUsr_id() > 0)
                    ins = false;

                int verb = Request.Method.POST;

                if (!ins) {
                    verb = Request.Method.PUT;
                }


                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jObj = new JSONObject(response);
                                    if (ins && jObj.has("insertId") && jObj.getInt("insertId") > 0) {
                                        int id = jObj.getInt("insertId");
                                        obj.setUsr_id(id);
                                        Globals.getInstance().loggedUser = obj;
                                        if (handler != null)
                                            handler.sendEmptyMessage(1);
                                    } else if (!ins && jObj.has("changedRows") && jObj.getInt("changedRows") > 0){
                                        Globals.getInstance().loggedUser = obj;
                                        Globals.getInstance().saveUserInPrefs();
                                        Globals.getInstance().handlerUI.sendEmptyMessage(102); // Atualiza header do navigation drawer
                                        if (handler != null)
                                            handler.sendEmptyMessage(1);
                                    } else {
                                        if (handler != null)
                                            handler.sendEmptyMessage(0);
                                    }
                                } catch (JSONException e) {
                                    if (handler != null)
                                        handler.sendEmptyMessage(0);
                                    Utils.Show("API Error (JSon) Login : " + e.getMessage(), true);
                                }
                            }
                        }, this){

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> params = new HashMap<String, String>();

                        /*if (ins){
                            params.put("usuario", "admin");
                            params.put("senha", "81dc9bdb52d04dc20036dbd8313ed055");
                        } else {
                            params.put("usuario", Utils.loggedUser.getUser());
                            params.put("senha", Utils.loggedUser.getPassword());
                        }*/

                        if (!ins)
                            params.put("USR_ID", String.valueOf(obj.getUsr_id()));

                        params.put("USR_NOME", Utils.DefStrVal(obj.getUsr_nome(), ""));
                        params.put("USR_SOBRENOME", Utils.DefStrVal(obj.getUsr_sobrenome(), ""));
                        params.put("USR_EMAIL", Utils.DefStrVal(obj.getUsr_email(), ""));
                        params.put("USR_TELEFONE", Utils.DefStrVal(obj.getUsr_telefone(), ""));
                        params.put("USR_UF", Utils.DefStrVal(obj.getUsr_uf(), ""));
                        params.put("USR_CIDADE", Utils.DefStrVal(obj.getUsr_cidade(), ""));
                        if (ins || (obj.getUsr_senha() != null && obj.getUsr_senha().length() > 0))
                            params.put("USR_SENHA", Utils.DefStrVal(Utils.HashMD5(Utils.DefStrVal(obj.getUsr_senha(), "")), ""));
                        if (!ins && !Globals.getInstance().loggedUser.getUsr_email().equals(obj.getUsr_email()))
                            params.put("USR_STATUS", "0");
                        else
                            params.put("USR_STATUS", String.valueOf(obj.getUsr_status()));
                        params.put("USR_DEVICE", Utils.DefStrVal(obj.getUsr_device(), ""));

                        return params;
                    }
                };

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error SaveUser : " + e.getMessage(), true);
        }
    }

    public void SaveVehicle(Handler h, final Vehicle obj) {
        try {
            handler = h;
            ins = true;

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "vehicle";
                if (obj.getVei_id() > 0)
                    ins = false;

                int verb = Request.Method.POST;

                if (!ins) {
                    verb = Request.Method.PUT;
                }


                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject jObj = new JSONObject(response);
                                    if (ins && jObj.has("insertId") && jObj.getInt("insertId") > 0) {
                                        int id = jObj.getInt("insertId");
                                        obj.setVei_id(id);
                                        Globals.getInstance().loggedVehicle = obj;
                                        Globals.getInstance().saveVehicleInPrefs();
                                        if (handler != null)
                                            handler.sendEmptyMessage(1);
                                    } else if (!ins && jObj.has("changedRows") && jObj.getInt("changedRows") > 0){
                                        Globals.getInstance().loggedVehicle = obj;
                                        Globals.getInstance().saveVehicleInPrefs();
                                        if (handler != null)
                                            handler.sendEmptyMessage(1);
                                    } else {
                                        if (handler != null)
                                            handler.sendEmptyMessage(0);
                                    }
                                } catch (JSONException e) {
                                    if (handler != null)
                                        handler.sendEmptyMessage(0);
                                    Utils.Show("API Error (JSon) SaveVehicle : " + e.getMessage(), true);
                                }
                            }
                        }, this){

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> params = new HashMap<String, String>();

                        params.put("USR_ID", String.valueOf(Globals.getInstance().loggedUser.getUsr_id()));
                        params.put("VEI_MARCA", Utils.DefStrVal(obj.getVei_marca(), ""));
                        params.put("VEI_MODELO", Utils.DefStrVal(obj.getVei_modelo(), ""));
                        params.put("VEI_COR", Utils.DefStrVal(obj.getVei_cor(), ""));
                        params.put("VEI_ANO", Utils.DefStrVal(obj.getVei_ano(), ""));
                        params.put("VEI_COBERTURA", Utils.DefStrVal(obj.getVei_cobertura(), ""));

                        return params;
                    }
                };

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error SaveVehicle : " + e.getMessage(), true);
        }
    }

    public void SaveNote(Handler h, final Note obj) {
        try {
            handler = h;

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "note";

                int verb = Request.Method.PUT;

                StringRequest req = new StringRequest(verb, path,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    if (handler != null)
                                        handler.sendEmptyMessage(0);
                                } catch (Exception e) {
                                    Utils.Show("API Error (JSon) SaveNote : " + e.getMessage(), true);
                                }
                            }
                        }, this){

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> params = new HashMap<String, String>();

                        params.put("NOT_ID", String.valueOf(obj.getNot_id()));
                        params.put("USR_ID", String.valueOf(obj.getUsr_id()));
                        params.put("NOT_TITULO", Utils.DefStrVal(obj.getNot_titulo(), ""));
                        params.put("NOT_MENSAGEM", Utils.DefStrVal(obj.getNot_mensagem(), ""));
                        params.put("NOT_TIPO", Utils.DefStrVal(obj.getNot_tipo(), ""));
                        params.put("NOT_OPCAOA", Utils.DefStrVal(obj.getNot_opcaoa(), ""));
                        params.put("NOT_OPCAOB", Utils.DefStrVal(obj.getNot_opcaob(), ""));
                        params.put("NOT_OPCAOC", Utils.DefStrVal(obj.getNot_opcaoc(), ""));
                        params.put("NOT_OPCAOD", Utils.DefStrVal(obj.getNot_opcaod(), ""));
                        params.put("NOT_OPCAOE", Utils.DefStrVal(obj.getNot_opcaoe(), ""));
                        params.put("NOT_RESPOSTA", Utils.DefStrVal(obj.getNot_resposta(), ""));
                        params.put("NOT_PUSH", Utils.DefStrVal(String.valueOf(obj.getNot_push()), ""));

                        return params;
                    }
                };

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error SaveNote : " + e.getMessage(), true);
        }
    }

    public void SaveWaypoints(final List<Waypoint> waypoints, Handler h) {
        try {
            handler = h;
            ins = true;

            if (!Utils.verificaConexao()) {
                Utils.Show("Sem conexão.", true);
            } else {
                String path = Globals.getInstance().apiPath + "waypoints";

                int verb = Request.Method.POST;

                String strArr = Globals.getInstance().gson.toJson(waypoints, new TypeToken<ArrayList<Waypoint>>() {}.getType());

                strArr = "{ 'waypoints' : " + strArr + "}";

                JSONObject arr = new JSONObject(strArr);

                JsonObjectRequest req = new JsonObjectRequest(verb, path, arr,

                        new Response.Listener<JSONObject>()
                        {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    String resp = response.toString();
                                    Globals.getInstance().db.deleteWaypoints();
                                } catch (Exception e) {
                                    handler.sendEmptyMessage(0);
                                    Utils.Show("API Error (JSon) SaveWaypoint : " + e.getMessage(), true);
                                }
                            }
                        }, this){};

                req.setRetryPolicy(new DefaultRetryPolicy(
                        10000,
                        3,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

                // Adding request to request queue
                VolleyHelper.getInstance().addToRequestQueue(req, "tag");
            }
        } catch (Exception e) {
            Utils.Show("API Error SaveWaypoint : " + e.getMessage(), true);
        }
    }

    public void Upload(final Object obj, String filenName, Handler h) {
        try {
            handler = h;
            String path = Globals.getInstance().apiPath + "upload";

            PhotoMultipartRequest imageUploadReq = new PhotoMultipartRequest(path,
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            String a = error.getMessage();
                            handler.sendEmptyMessage(0);
                        }
                    },
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            handler.sendEmptyMessage(1);
                        }
                    }, (byte[]) obj, filenName);

            imageUploadReq.setRetryPolicy(new DefaultRetryPolicy(
                    10000,
                    3,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

            VolleyHelper.getInstance().addToRequestQueue(imageUploadReq, "any_tag");
        } catch (Exception e) {
            Utils.Show("API Error Upload : " + e.getMessage(), true);
        }
    }

    //--------------------------------------------

    public List<Note> FillArrayNoteWithJSON(JSONArray arr) {
        List<Note> list = new ArrayList<Note>();
        Note newObj;

        try {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = (JSONObject) arr.get(i);

                newObj = FillNoteWithJSON(obj);
                list.add(newObj);
            }
        } catch (JSONException e) {
            Utils.Show("FillArrayNoteWithJSON - Erro JSON : " + e.getMessage(), true);
        }

        return list;
    }

    public Note FillNoteWithJSON(JSONObject obj) {
        Note newObj = new Note();

        try {
            if (!obj.isNull("NOT_ID"))
                newObj.setNot_id(obj.getInt("NOT_ID"));
            if (!obj.isNull("USR_ID"))
                newObj.setUsr_id(obj.getInt("USR_ID"));
            if (!obj.isNull("NOT_MENSAGEM"))
                newObj.setNot_mensagem(obj.getString("NOT_MENSAGEM"));
            if (!obj.isNull("NOT_TITULO"))
                newObj.setNot_titulo(obj.getString("NOT_TITULO"));
            if (!obj.isNull("NOT_RESPOSTA"))
                newObj.setNot_resposta(obj.getString("NOT_RESPOSTA"));
            if (!obj.isNull("NOT_TIPO"))
                newObj.setNot_tipo(obj.getString("NOT_TIPO"));
            if (!obj.isNull("NOT_PUSH"))
                newObj.setNot_push(obj.getInt("NOT_PUSH"));
            if (!obj.isNull("NOT_OPCAOA"))
                newObj.setNot_opcaoa(obj.getString("NOT_OPCAOA"));
            if (!obj.isNull("NOT_OPCAOB"))
                newObj.setNot_opcaob(obj.getString("NOT_OPCAOB"));
            if (!obj.isNull("NOT_OPCAOC"))
                newObj.setNot_opcaoc(obj.getString("NOT_OPCAOC"));
            if (!obj.isNull("NOT_OPCAOD"))
                newObj.setNot_opcaod(obj.getString("NOT_OPCAOD"));
            if (!obj.isNull("NOT_OPCAOE"))
                newObj.setNot_opcaoe(obj.getString("NOT_OPCAOE"));
        } catch (JSONException e) {
            Utils.Show("FillNoteWithJSON - Erro JSON", true);
        }

        return newObj;
    }

    public User FillUserWithJSON(JSONObject obj) {
        User newObj = new User();

        try {
            if (!obj.isNull("USR_ID"))
                newObj.setUsr_id(obj.getInt("USR_ID"));
            if (!obj.isNull("USR_NOME"))
                newObj.setUsr_nome(obj.getString("USR_NOME"));
            if (!obj.isNull("USR_SOBRENOME"))
                newObj.setUsr_sobrenome(obj.getString("USR_SOBRENOME"));
            if (!obj.isNull("USR_EMAIL"))
                newObj.setUsr_email(obj.getString("USR_EMAIL"));
            if (!obj.isNull("USR_TELEFONE"))
                newObj.setUsr_telefone(obj.getString("USR_TELEFONE"));
            if (!obj.isNull("USR_UF"))
                newObj.setUsr_uf(obj.getString("USR_UF"));
            if (!obj.isNull("USR_CIDADE"))
                newObj.setUsr_cidade(obj.getString("USR_CIDADE"));
            if (!obj.isNull("USR_DEVICE"))
                newObj.setUsr_device(obj.getString("USR_DEVICE"));
            if (!obj.isNull("USR_STATUS"))
                newObj.setUsr_status(obj.getInt("USR_STATUS"));

        } catch (JSONException e) {
            Utils.Show("FillUserWithJSON - Erro JSON", true);
        }

        return newObj;
    }

    public Vehicle FillVehicleWithJSON(JSONObject obj) {
        Vehicle newObj = new Vehicle();

        try {
            if (!obj.isNull("USR_ID"))
                newObj.setUsr_id(obj.getInt("USR_ID"));
            if (!obj.isNull("VEI_ID"))
                newObj.setVei_id(obj.getInt("VEI_ID"));
            if (!obj.isNull("VEI_MARCA"))
                newObj.setVei_marca(obj.getString("VEI_MARCA"));
            if (!obj.isNull("VEI_MODELO"))
                newObj.setVei_modelo(obj.getString("VEI_MODELO"));
            if (!obj.isNull("VEI_ANO"))
                newObj.setVei_ano(obj.getString("VEI_ANO"));
            if (!obj.isNull("VEI_COR"))
                newObj.setVei_cor(obj.getString("VEI_COR"));
            if (!obj.isNull("VEI_COBERTURA"))
                newObj.setVei_cobertura(obj.getString("VEI_COBERTURA"));

        } catch (JSONException e) {
            Utils.Show("FillVehicleWithJSON - Erro JSON", true);
        }

        return newObj;
    }

    public Waypoint FillWaypointWithJSON(JSONObject obj) {
        Waypoint newObj = new Waypoint();

        try {
            if (!obj.isNull("WAY_ID"))
                newObj.setWay_id(obj.getInt("WAY_ID"));
            if (!obj.isNull("USR_ID"))
                newObj.setUsr_id(obj.getInt("USR_ID"));
            if (!obj.isNull("WAY_LATITUDE"))
                newObj.setWay_latitude(obj.getDouble("WAY_LATITUDE"));
            if (!obj.isNull("WAY_LONGITUDE"))
                newObj.setWay_longitude(obj.getDouble("WAY_LONGITUDE"));
            if (!obj.isNull("WAY_DATE"))
                newObj.setWay_date(obj.getString("WAY_DATE"));
            if (!obj.isNull("WAY_PERCORRIDO"))
                newObj.setWay_percorrido(obj.getDouble("WAY_PERCORRIDO"));

        } catch (JSONException e) {
            Utils.Show("FillVehicleWithJSON - Erro JSON", true);
        }

        return newObj;
    }
}
