package br.com.aidavec.aidavec.fragments;


import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import br.com.aidavec.aidavec.R;
import br.com.aidavec.aidavec.core.AidavecController;
import br.com.aidavec.aidavec.core.Globals;
import br.com.aidavec.aidavec.core.Api;
import br.com.aidavec.aidavec.models.Waypoint;
import br.com.aidavec.aidavec.models.WaypointServer;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class HomeFrag extends Fragment {

    private TextView txt;
    private TextView lblBack;
    Button btnBack;
    boolean canContinue;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.frag_home, container, false);

      //  txt = (TextView) v.findViewById(R.id.lblText);
     //   lblBack = (TextView) v.findViewById(R.id.lblBack);
        btnBack = (Button) v.findViewById(R.id.btnBack);

        Globals.getInstance().handlerHome = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                txt.setText(Globals.getInstance().lastWaypointCreated.getWay_date() + " - " +
                        String.valueOf(Globals.getInstance().lastWaypointCreated.getWay_latitude()) + " - " +
                        String.valueOf(Globals.getInstance().lastWaypointCreated.getWay_longitude()));
            }
        };

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Backup();
            }
        });

        return v;
    }

    private void Backup() {
        List<Waypoint> waypoints = Globals.getInstance().db.getWaypoints();
      //  List<WaypointServer> serverWaypoints = AidavecController.getInstance().decodeWaypoints(waypoints);

        Api.getInstance().SaveWaypoints(waypoints, handler);
    }
}


