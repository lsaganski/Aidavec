package br.com.aidavec.aidavec.services;

import android.app.Activity;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.location.LocationResult;

import br.com.aidavec.aidavec.core.AidavecDB;
import br.com.aidavec.aidavec.core.Globals;
import br.com.aidavec.aidavec.helpers.Utils;

/**
 * Created by leonardo.saganski on 30/11/16.
 */

public class AidavecLocationService extends IntentService {

    private static AidavecLocationService instance;

    public static final String TAG = "AidavecLocationService";
    Context _context;

    public static AidavecLocationService getInstance() {
        if (instance == null)
            instance = new AidavecLocationService();

        return instance;
    }

    public AidavecLocationService() {
        super("AidavecLocationService");

        _context = Globals.getInstance().context;

    }

    @Override
    protected void onHandleIntent(Intent intent) {
        try {
            if (LocationResult.hasResult(intent)) {
                LocationResult result = LocationResult.extractResult(intent);
                Location location = result.getLastLocation();

                LocationReceiver rec = intent.getParcelableExtra("receiver");
                // Extract additional values from the bundle
                //String val = intent.getStringExtra("foo");
                // To send a message to the Activity, create a pass a Bundle
                Bundle bundle = new Bundle();
                bundle.putDouble("resultLatitude", location.getLatitude());
                bundle.putDouble("resultLongitude", location.getLongitude());
                // Here we call send passing a resultCode and the bundle of extras
                rec.send(Activity.RESULT_OK, bundle);

            }
        } catch (Exception e) {
            if (Utils.isMyServiceRunning(AidavecLocationService.class)) {
//                AidavecLocationService.getInstance().stopService(new Intent(this, AidavecLocationService.class));
                AidavecLocationService.getInstance().onDestroy();
            }

            if (Utils.isMyServiceRunning(AidavecMotionService.class)) {
//                AidavecMotionService.getInstance().stopService(new Intent(this, AidavecMotionService.class));
                AidavecMotionService.getInstance().onDestroy();
            }
        }
    }

    public void handleNewLocation(Location location) {
        try {
            Log.i("LOG", "latitude(" + location.getLatitude() + ")");
            Log.i("LOG", "longitude(" + location.getLongitude() + ")");

            //AidavecDB.getInstance().saveWaypoint(location.getLatitude(), location.getLongitude());

            // Extract the receiver passed into the service
        } catch (Exception e) {
            if (Utils.isMyServiceRunning(AidavecLocationService.class)) {
         //       AidavecLocationService.getInstance().stopService(new Intent(this, AidavecLocationService.class));
                AidavecLocationService.getInstance().onDestroy();
            }

            if (Utils.isMyServiceRunning(AidavecMotionService.class)) {
         //       AidavecMotionService.getInstance().stopService(new Intent(this, AidavecMotionService.class));
                AidavecMotionService.getInstance().onDestroy();
            }
        }
    }
}
