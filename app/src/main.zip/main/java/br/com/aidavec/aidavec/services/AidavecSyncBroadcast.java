package br.com.aidavec.aidavec.services;

import android.app.IntentService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.List;

import br.com.aidavec.aidavec.core.Api;
import br.com.aidavec.aidavec.core.Globals;
import br.com.aidavec.aidavec.models.Waypoint;

/**
 * Created by leonardo.saganski on 10/01/17.
 */

public class AidavecSyncBroadcast extends BroadcastReceiver {

    public static final int REQUEST_CODE = 12345;
    public static final String ACTION = "br.com.aidavec.alarm";

    @Override
    public void onReceive(Context context, Intent intent) {
        List<Waypoint> waypoints = Globals.getInstance().db.getWaypoints();

        if (waypoints.size() > 0) {
            Api.getInstance().SaveWaypoints(waypoints, null);
        }
    }
}
