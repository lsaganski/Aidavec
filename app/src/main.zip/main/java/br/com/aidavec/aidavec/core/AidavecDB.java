package br.com.aidavec.aidavec.core;

import android.content.Intent;
import android.os.Bundle;
import android.os.Message;

import br.com.aidavec.aidavec.helpers.Utils;
import br.com.aidavec.aidavec.models.Waypoint;
import br.com.aidavec.aidavec.services.AidavecLocationService;
import br.com.aidavec.aidavec.services.AidavecMotionService;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class AidavecDB {

    private static AidavecDB instance;

    public static AidavecDB getInstance() {
        if (instance == null)
            instance = new AidavecDB();

        return instance;
    }

    public void saveWaypoint(double latitude, double longitude) {
        try {
            Waypoint w = new Waypoint();
            w.setUsr_id(Globals.getInstance().loggedUser.getUsr_id());
            w.setWay_date(Utils.getInstance().getStringNow());
            w.setWay_latitude(latitude);
            w.setWay_longitude(longitude);
            w.setWay_percorrido(AidavecController.getInstance().getDistanciaEntrePontos(w));

            Globals.getInstance().db.addWaypoint(w);

            Globals.getInstance().lastWaypointCreated = w;

            Globals.getInstance().handlerHome.sendEmptyMessage(0);  // atualiza coordenadas
        } catch (Exception e) {
            AidavecLocationService.getInstance().stopService(new Intent( Globals.getInstance().context, AidavecLocationService.class ));
            AidavecLocationService.getInstance().onDestroy();

            AidavecMotionService.getInstance().stopService(new Intent( Globals.getInstance().context, AidavecMotionService.class ));
            AidavecMotionService.getInstance().onDestroy();

        }
    }
}
