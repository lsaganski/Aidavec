package br.com.aidavec.aidavec.helpers;

import android.app.ActivityManager;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v4.content.CursorLoader;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.Toast;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import br.com.aidavec.aidavec.core.Globals;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class Utils {

    boolean mResult;



    private static Utils instance;

    public static Utils getInstance() {
        if (instance == null)
            instance = new Utils();

        return instance;
    }

    public String getStringNow() {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String formattedDate = df.format(Calendar.getInstance().getTime());

        return formattedDate;
    }

    public static void Show(String msg, boolean longToast){
        Toast t = Toast.makeText(Globals.getInstance().context, msg, longToast ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT);
        t.setGravity(Gravity.TOP| Gravity.RIGHT, 0, 0);
        t.show();
    }

    public static boolean verificaConexao() {
        boolean conectado;
        ConnectivityManager conectivtyManager = (ConnectivityManager) Globals.getInstance().context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (conectivtyManager.getActiveNetworkInfo() != null
                && conectivtyManager.getActiveNetworkInfo().isAvailable()
                && conectivtyManager.getActiveNetworkInfo().isConnected()) {
            conectado = true;
        } else {
            conectado = false;
        }
        return conectado;
    }

    public boolean getYesNoWithExecutionStop(String title, String message,
                                             Context context) {

/*        final Handler handler = new Handler() {
            @Override
            public void handleMessage(Message mesg) {
                throw new RuntimeException();
            }
        };*/

        AlertDialog.Builder alert = new AlertDialog.Builder(context);
        alert.setTitle(title);
        alert.setMessage(message);
        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                mResult = true;
               /* handler.sendMessage(handler.obtainMessage());*/
            }
        });

        alert.show();

        try {
            Looper.loop();
        } catch (RuntimeException e2) {
        }

        return mResult;
    }

    public boolean getYesNoConfirmWithExecutionStop(String title, String message, String Sim, String Nao,
                                                    Context context) {

        final Handler handler = new Handler() {
            @Override
            public void handleMessage(Message mesg) {
                throw new RuntimeException();
            }
        };

        AlertDialog.Builder alert = new AlertDialog.Builder(Globals.getInstance().context);
        alert.setTitle(title);
        alert.setMessage(message);
        alert.setPositiveButton(Nao, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                mResult = false;
                handler.sendMessage(handler.obtainMessage());
            }
        });
        alert.setNegativeButton(Sim, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                mResult = true;
                handler.sendMessage(handler.obtainMessage());
            }
        });

        alert.show();

        try {
            Looper.loop();
        } catch (RuntimeException e2) {
        }

        return mResult;
    }

    public static String DefStrVal(String valor, String defaultValue){
        if (valor == null)
            return defaultValue;
        else
            return valor;
    }

    public static String HashMD5(String s) {
        String res = "";

        try {
            MessageDigest m = MessageDigest.getInstance("MD5");
            m.update(s.getBytes(), 0, s.length());
            res = new BigInteger(1, m.digest()).toString(16);
        } catch (Exception e) {

        }

        return res;
    }

    public static String CleanStr(String s){
        return s.toUpperCase()
                .replace('Ã','A')
                .replace('Á','A')
                .replace('Â','A')
                .replace('À','A')
                .replace('É','E')
                .replace('Õ','O')
                .replace('Ó','O')
                .replace('Ô','O')
                .replace('Í','I')
                .replace('Ú','U')
                .replace('Ç','C');
    }

    public static String MaskPhone(String v)
    {
        if (v.length() > 0 && v.charAt(0) != '(')
            v = '(' + v;

        if (v.length() > 3 && v.charAt(3) != ')')
            v = v.substring(0, 2) + ')' + v.substring(3, v.length()-1);

        return v;
    }

    public static boolean isValidEmail(String target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }

    public static String getPathFromURI(Uri contentUri) {
        String[] proj = { MediaStore.Images.Media.DATA };
        CursorLoader loader = new CursorLoader(Globals.getInstance().context, contentUri, proj, null, null, null);
        Cursor cursor = loader.loadInBackground();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public static boolean isMyServiceRunning(Class<?> serviceClass) {
        if (Globals.getInstance() != null && Globals.getInstance().context != null) {
            ActivityManager manager = (ActivityManager) Globals.getInstance().context.getSystemService(Context.ACTIVITY_SERVICE);

            if (manager != null) {
                for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                    if (serviceClass.getName().equals(service.service.getClassName())) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public double calculaDistancia(double lat1, double lng1, double lat2, double lng2) {
        //double earthRadius = 3958.75;//miles
        double earthRadius = 6371;//kilometers
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);
        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2));
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double dist = earthRadius * c;

        return dist; // * 1000; //em metros
    }
}
