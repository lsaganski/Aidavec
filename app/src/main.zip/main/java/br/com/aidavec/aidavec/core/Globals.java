package br.com.aidavec.aidavec.core;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v4.app.Fragment;

import com.google.gson.Gson;

import br.com.aidavec.aidavec.helpers.SQLiteHandler;
import br.com.aidavec.aidavec.models.Note;
import br.com.aidavec.aidavec.models.User;
import br.com.aidavec.aidavec.models.Vehicle;
import br.com.aidavec.aidavec.models.Waypoint;
import br.com.aidavec.aidavec.models.WaypointServer;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class Globals {

    private static Globals instance;

    public User loggedUser;
    public Vehicle loggedVehicle;
    public Context context;
    public SQLiteHandler db;
    public Handler handlerHome;
    public int countUnreadNotes;
    public Handler handlerUI;
    public String deviceToken;
    public Note lastPush;
    public Waypoint lastWaypointCreated;

    public Fragment showThisFrag;

    public static SharedPreferences mPrefs;
    public static SharedPreferences.Editor prefsEditor;
    public static Gson gson;

    public String apiPath = "http://www.mobila.kinghost.net/aidavecapi/api/";

    public static Globals getInstance() {
        if (instance == null)
            instance = new Globals();

        return instance;
    }

    public Globals() {

    }

    public void setupDB() {
        db = new SQLiteHandler(context);
    }

    public void startCountUnreadNotes()  {
        if (mPrefs.contains("countUnreadNotes")) {
            countUnreadNotes = Integer.valueOf(mPrefs.getString("countUnreadNotes", ""));
        } else {
            countUnreadNotes = 0;
        }

        handlerUI.sendEmptyMessage(101);
    }

    public void increaseCountUnreadNotes()  {
        countUnreadNotes = countUnreadNotes + 1;
        handlerUI.sendEmptyMessage(101);
    }

    public void clearCountUnreadNotes()  {
        countUnreadNotes = 0;
        handlerUI.sendEmptyMessage(101);
    }

    public void updateDeviceTokenIfNeeded() {
        if (deviceToken != null && !loggedUser.getUsr_device().equals(deviceToken)) {
            loggedUser.setUsr_device(deviceToken);
            Api.getInstance().SaveUser(null, loggedUser);
        }
    }

    public void saveVehicleInPrefs() {
        String jsonVei = gson.toJson(loggedVehicle);
        prefsEditor.putString("loggedVehicle", jsonVei);
        prefsEditor.commit();
    }

    public void saveUserInPrefs() {
        String jsonUser = gson.toJson(loggedUser);
        prefsEditor.putString("loggedUser", jsonUser);
        prefsEditor.commit();
    }
}
