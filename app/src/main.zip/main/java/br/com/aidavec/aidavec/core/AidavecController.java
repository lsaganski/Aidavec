package br.com.aidavec.aidavec.core;

import android.os.Handler;
import android.os.Message;

import org.joda.time.Period;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import br.com.aidavec.aidavec.helpers.Utils;
import br.com.aidavec.aidavec.models.Waypoint;
import br.com.aidavec.aidavec.models.WaypointServer;

/**
 * Created by leonardo.saganski on 09/01/17.
 */

public class AidavecController {

    private static AidavecController instance;

    public static AidavecController getInstance() {
        if (instance == null)
            instance = new AidavecController();

        return instance;
    }

    public void getLastWaypoint() {
        if (Globals.getInstance().lastWaypointCreated == null) {
            List<Waypoint> localWays = Globals.getInstance().db.getWaypoints();

            if (localWays.size() > 0) {
                Globals.getInstance().lastWaypointCreated = localWays.get(localWays.size() - 1);
            } else {
                Api.getInstance().GetLastWaypoint();
            }
        }
    }

    public double getDistanciaEntrePontos(Waypoint w) {
        double distancia = 0;

        // Verifica se no Splash foi capturado o ultimo waypoint, caso nao, provavlmente este é o primeiro, entao retorna 0.
        if (Globals.getInstance().lastWaypointCreated != null) {
            // Pega o intervalo entre a data/hora do ultimo waypoint e do atual
            Date a = new Date(Globals.getInstance().lastWaypointCreated.getWay_date());
            Date b = new Date(w.getWay_date());
            Period period = new Period(a.getTime(), b.getTime());
            long seconds = period.getSeconds();
            // Se o intervalo for menor ou igual a 7 segundos, então pertence a mesma viagem e retorna a distancia entre os pontos,
            // Senão, não pertence à mesma viagem e retorna 0.
            if (seconds <= 7) {
                distancia = Utils.getInstance().calculaDistancia(w.getWay_latitude(), w.getWay_longitude(),
                        Globals.getInstance().lastWaypointCreated.getWay_latitude(),
                        Globals.getInstance().lastWaypointCreated.getWay_longitude());
            }
        }

        return distancia;
    }
}
