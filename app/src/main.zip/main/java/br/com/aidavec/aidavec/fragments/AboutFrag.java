package br.com.aidavec.aidavec.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import br.com.aidavec.aidavec.R;

/**
 * Created by leonardo.saganski on 03/01/17.
 */

public class AboutFrag extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_about, container, false);

        return v;
    }

}