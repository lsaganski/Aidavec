package br.com.aidavec.aidavec.fragments;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import br.com.aidavec.aidavec.R;
import br.com.aidavec.aidavec.core.Globals;
import br.com.aidavec.aidavec.services.AidavecSyncBroadcast;
import br.com.aidavec.aidavec.views.LoginActivity;

/**
 * Created by Leonardo Saganski on 27/11/16.
 */
public class ConfigFrag extends Fragment {

    Button btnPerfil;
    Button btnVeiculo;
    Button btnSair;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_config, container, false);

        btnPerfil = (Button) v.findViewById(R.id.btnPerfil);
        btnVeiculo = (Button) v.findViewById(R.id.btnVeiculo);
        btnSair = (Button) v.findViewById(R.id.btnSair);

        btnPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.nav_contentframe, new ProfileFrag(), "TAG").commit();
            }
        });

        btnVeiculo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.nav_contentframe, new VehicleFrag(), "TAG").commit();
            }
        });

        btnSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelAlarm();

                Globals.getInstance().prefsEditor.remove("loggedUser");
                Globals.getInstance().prefsEditor.remove("loggedVehicle");
                Globals.getInstance().prefsEditor.commit();

                Intent intent = new Intent(Globals.getInstance().context, LoginActivity.class);
                startActivity(intent);
            }
        });

        return v;
    }

    private void cancelAlarm() {
        Intent intent = new Intent(getActivity().getApplicationContext(), AidavecSyncBroadcast.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(getActivity(), AidavecSyncBroadcast.REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);
        alarm.cancel(pIntent);
    }
}
