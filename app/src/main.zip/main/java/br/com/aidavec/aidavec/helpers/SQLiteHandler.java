package br.com.aidavec.aidavec.helpers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import br.com.aidavec.aidavec.models.Waypoint;

/**
 * Created by Guilherme on 01-Nov-15.
 */
public class SQLiteHandler extends SQLiteOpenHelper {

    private static final String TAG = SQLiteHandler.class.getSimpleName();

    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 2;

    // Database Name
    private static final String DATABASE_NAME = "AIDAVEC";

    public SQLiteHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        // AID_WAYPOINTS
        db.execSQL("DROP TABLE IF EXISTS AID_WAYPOINTS");

        String CREATE_WAYPOINTS_TABLE = "CREATE TABLE AID_WAYPOINTS ("
                + "WAY_ID INTEGER PRIMARY KEY,"
                + "USR_ID INTEGER,"
                + "WAY_DATE TEXT,"
                + "WAY_LATITUDE TEXT,"
                + "WAY_LONGITUDE TEXT,"
                + "WAY_PERCORRIDO TEXT" + ")";
        db.execSQL(CREATE_WAYPOINTS_TABLE);

        Log.d(TAG, "Database tables created");
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Create tables again
        onCreate(db);
    }

    /**
     * Storing waypoint in database
     * */
    public void addWaypoint(Waypoint w) {
        SQLiteDatabase db = this.getWritableDatabase();

//        onCreate(db);

        String now = Utils.getInstance().getStringNow();
        ContentValues values = new ContentValues();
        values.put("USR_ID", w.getUsr_id());
        values.put("WAY_DATE", w.getWay_date());
        values.put("WAY_LATITUDE", w.getWay_latitude());
        values.put("WAY_LONGITUDE", w.getWay_longitude());
        values.put("WAY_PERCORRIDO", w.getWay_percorrido());

        // Inserting Row
        long id = db.insert("AID_WAYPOINTS", null, values);
        db.close(); // Closing database connection

       // Log.d(TAG, "New waypoint inserted into sqlite: " + waydata + " )");
    }

    /**
     * Getting waypoint data from database
     * */
    public List<Waypoint> getWaypoints() {
        List<Waypoint> waypoints = new ArrayList<Waypoint>();
        Waypoint waypoint;
        String selectQuery = "SELECT  * FROM AID_WAYPOINTS";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // Move to first row
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            waypoint = new Waypoint();
            waypoint.setUsr_id(Integer.valueOf(cursor.getString(0)));
            waypoint.setWay_date(cursor.getString(1));
            waypoint.setWay_latitude(cursor.getDouble(2));
            waypoint.setWay_longitude(cursor.getDouble(3));
            waypoint.setWay_percorrido(cursor.getDouble(4));
            waypoints.add(waypoint);
            cursor.moveToNext();
        }
        cursor.close();
        db.close();

        return waypoints;
    }

    public void deleteWaypoints() {
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete All Rows
        db.delete("AID_WAYPOINTS", null, null);
        db.close();

        Log.d(TAG, "Deleted all waypoints info from sqlite");
    }

}